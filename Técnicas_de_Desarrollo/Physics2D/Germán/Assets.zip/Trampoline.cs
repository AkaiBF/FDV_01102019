﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trampoline : MonoBehaviour
{
    Animator trampolineAnimator;
    // Start is called before the first frame update
    void Start()
    {
        trampolineAnimator = GetComponent<Animator>();
    }


    void OnCollisionEnter2D (Collision2D other){
      other.gameObject.GetComponent<Rigidbody2D>().AddForce(Vector2.up * 200);
      trampolineAnimator.SetBool("Touching", true);
      Debug.Log("Hola");
    }

    void OnCollisionExit2D (Collision2D other){
      trampolineAnimator.SetBool("Touching", false);
    }
    // Update is called once per frame
    void Update()
    {

    }
}
