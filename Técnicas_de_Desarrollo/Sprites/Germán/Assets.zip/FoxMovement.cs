﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoxMovement : MonoBehaviour
{
    float scaleMoveForward = 0.03f;
    Animator animator;
    SpriteRenderer renderer;
    Rigidbody2D rigidbody;
    bool jumping;
    // Start is called before the first frame update
    void Start()
    {
      rigidbody = GetComponent<Rigidbody2D>();
      animator = GetComponent<Animator>();
      renderer = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if(rigidbody.velocity.y > 0) jumping = true;
        else jumping = false;
        float moveForward = scaleMoveForward*Input.GetAxis("Horizontal");
        if(Input.GetAxis("Horizontal") != 0){
          animator.SetBool("Running", true);
          if(Input.GetAxis("Horizontal") < 0) renderer.flipX = true;
          else renderer.flipX = false;
        }
        else animator.SetBool("Running", false);

        if(Input.GetAxis("Vertical") > 0 && !jumping){
          rigidbody.AddForce(Vector2.up*200);
        }

        transform.position+=moveForward*transform.right;
    }
}
