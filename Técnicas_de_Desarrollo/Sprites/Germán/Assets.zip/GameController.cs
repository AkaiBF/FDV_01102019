﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class GameController : MonoBehaviour
{
    Animator huskyAnimator;
    public GameObject husky;
    public GameObject fox;
    // Start is called before the first frame update
    void Start()
    {
        huskyAnimator = husky.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        huskyAnimator.SetFloat("Distance2Fox", System.Math.Abs(fox.transform.position.x - husky.transform.position.x));

    }
}
