﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public static float timeElapsed = 0f;
    public List<GameObject> powerUps = new List<GameObject>();
    public Material black;
    public GameObject redSphere;
    public GameObject blueSphere;
    public GameObject greenSphere;
    public GameObject yellowSphere;
    public GameObject cube;

    // Generación automática -> cambio de lugar
    //

    // Start is called before the first frame update
    void Start()
    {
        cube.transform.position = new Vector3(Random.Range(-9, 9), 0.5f, Random.Range(-9, 9));
        powerUps.Add(redSphere);
        powerUps.Add(blueSphere);
        powerUps.Add(greenSphere);
        powerUps.Add(yellowSphere);
        powerUps.ForEach(delegate (GameObject powerUp)
        {
          powerUp.transform.position = new Vector3(Random.Range(-9, 9), 0.5f, Random.Range(-9, 9));
        });
    }

    // Update is called once per frame
    void Update()
    {

        timeElapsed += Time.deltaTime;
        if (timeElapsed >= 10f) {
            timeElapsed = timeElapsed % 10f;
            powerUps.ForEach(delegate (GameObject powerUp)
            {
              powerUp.transform.position = new Vector3(Random.Range(-9, 9), 0.5f, Random.Range(-9, 9));
            });
        }
    }
}
