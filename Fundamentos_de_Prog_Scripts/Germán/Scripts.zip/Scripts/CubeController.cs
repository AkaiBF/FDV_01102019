﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeController : MonoBehaviour
{
    private float moveForward = 0.0f;   // speed
    private float rotate = 0.0f;
    public float rotateSpeed = 2.0f;
    public float moveSpeed = 0.5f;
    public int powerObtained = 0;

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        moveForward = Input.GetAxis("Vertical");
        rotate = Input.GetAxis("Horizontal");
    }

    private void FixedUpdate()
    {
        transform.Rotate(0, rotate * rotateSpeed, 0);
        //transform.Translate(0, 0, moveForward * moveSpeed);
        Vector3 newPosition = transform.position + moveForward * moveSpeed * transform.forward;
        if (newPosition.x > -10 && newPosition.x < 10 && newPosition.z > -10 && newPosition.z < 10)
        {
            transform.Translate(transform.InverseTransformDirection(newPosition - transform.position));
        }
    }

    public void addPower(int newPower){
      powerObtained += newPower;
    }
}
