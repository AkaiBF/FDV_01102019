﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueSphereController : MonoBehaviour
{
    public int powerValue = 1;
    public bool used = false;
    public float distance2Cube;
    public Material black;
    public GameObject cube;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
      distance2Cube = (cube.transform.position - this.transform.position).magnitude;
      if(distance2Cube < 0.5 && !used){
        used = true;
        cube.GetComponent<CubeController>().addPower(powerValue);
        this.GetComponent<MeshRenderer>().material = black;
      }
    }
}
